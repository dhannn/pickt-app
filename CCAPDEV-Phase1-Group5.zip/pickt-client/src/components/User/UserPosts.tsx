import React from 'react';

type UserPostsProps = {
    
}

export function UserPosts() {

}