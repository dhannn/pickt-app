export type Vote = {
    upvotes: number,
    downvotes: number
};