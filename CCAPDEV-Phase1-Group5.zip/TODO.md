[x] Add Register page
[X] Add User page
[x] Add comment feature
[x] Add edit and delete options
[x] Fix README
[x] Add conditional rendering on comments (whether user is signed in or not)
[ ] Add modals for user login and sign up
[x] Add 'Add Picture' feature for posts
[ ] Implement replies
[ ] Add search bar functionality in front-end
[ ] Implement No User Found
[ ] Implement No Post Found
[ ] Populate About page
[ ] Refactor useUserAuth hook
[ ] Refactor AddPicture
[ ] Refactor getting BG in login
[ ] Daily Highlight
[ ] Add Collapsible search bar
